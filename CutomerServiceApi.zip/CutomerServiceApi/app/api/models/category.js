module.exports = {
  attributes: {
    image: {
      type: 'string'
    },
    category: {
      type: 'string'
    },
    type:{
      type:'string'
    },
    size:
    {
      type:'number'
    }
  }
};
