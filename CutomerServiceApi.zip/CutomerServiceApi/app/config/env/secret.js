var secret = "token";

exports.secret = secret ;
