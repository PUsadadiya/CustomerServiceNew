
module.exports.views = {
  layout: 'layouts/layout'

};
